# LibArduino
Abstracted library for Adafruit Neopixel Light Strip (https://github.com/adafruit/Adafruit_NeoPixel)
